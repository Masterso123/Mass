package com.smartpack.kernelmanager.utils;

/**
 * Created by willi on 27.11.17.
 */

public class NotificationId {

    public static final int APPLY_ON_BOOT = 1;
    public static final int APPLY_ON_BOOT_CONFIRMATION = 2;

}
