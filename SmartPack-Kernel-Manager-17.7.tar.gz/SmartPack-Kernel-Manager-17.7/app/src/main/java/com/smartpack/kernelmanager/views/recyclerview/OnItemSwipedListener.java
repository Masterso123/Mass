package com.smartpack.kernelmanager.views.recyclerview;

public interface OnItemSwipedListener {
    void onItemSwiped(RecyclerViewItem item, int position);
}
